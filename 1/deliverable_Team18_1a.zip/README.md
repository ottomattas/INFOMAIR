1c_dialogSystemInterface.py needs to have the unpacked training data folder
dstc2_traindev/ in the dataPath available for the program to use.
